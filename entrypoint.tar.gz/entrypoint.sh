#!/bin/bash

/etc/init.d/postgresql start

tail -f /dev/null